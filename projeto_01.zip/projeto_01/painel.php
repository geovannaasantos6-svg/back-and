<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <title>Painel🙈</title>
</head>
<body>

  <div style="border: 4px solid white; padding: 15px; width: 1490px; text-align:center">
    <H1 style="background-color:white;">Painel de Informações</H1>
    <p>Conteúdo do painel aqui.</p>
  </div>

  
  <header>
        <nav style="display: flex; justify-content: space-between" >
            <h3><a href="#home">Home</a></h3>
            <h3><a href="#sobre">Sobre</a></h3>
            <h3><a href="#artigos">Artigos</a></h3>
            <h3><a href="#contato">Contato</a></h3>
        </nav>
    </header>


  <section>
  <h2 style="background-color:white;width:100px">Sobre a Loja</h2>
  <p>Aqui estão informações sobre nossa loja.</p>
  <h2 style="background-color:white;width:100px">Últimas Notícias</h2>
  <p>Aqui estão as notícias recentes.</p>
  <h2 style="background-color:white;width:100px">Contato</h2>
  <p>Informações para falar conosco.</p>
</section>
<body style="background-color: #abae83ff;">
  <!-- Conteúdo aqui -->
</body>

</body>
</html>